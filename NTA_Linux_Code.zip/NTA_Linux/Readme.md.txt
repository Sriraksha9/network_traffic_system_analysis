##Network Traffic Analysis Project. 

With the use of Python and other data analysis and visualization tools this project seeks to create a Network Traffic Analysis (NTA) system that can examine network traffic data to find odd patterns of activity. 

#Project Particulars. 
 -Network traffic information in PCAP format (networktraffic2.pcap).

##Tools. 
- Python 3. X. - Pandas (for analysis and data shaping). 
- Matplotlib (for visualizing data). 
- Statsmodels which performs time series analysis and statistical modeling. 
- Network traffic capture and analysis program TCPdump. 
- The network protocol analyzer Wireshark. 
- Power BI which offers reporting and data visualization. Organization of the Project.